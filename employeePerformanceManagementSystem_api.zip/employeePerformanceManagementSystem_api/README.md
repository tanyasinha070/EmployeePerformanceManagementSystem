
# Student Management API (Spring Boot 3, Java 17)

Implements two endpoints with robust filtering and DTOs.

## Run
```bash
./mvnw spring-boot:run
```
or with Maven installed:
```bash
mvn spring-boot:run
```

H2 Console: `/h2-console`  
OpenAPI UI: `/swagger-ui.html`

## Endpoints

### 1) GET `/api/employee`
Filters:
- `minScore` (0..100) + `adDate` (ISO yyyy-MM-dd): filter by performance on that date with score >= minScore
- `courses` (CSV, contains match on course name): e.g. `courses=Comp,Math`
- `assignments` (CSV, contains match on assignment name): e.g. `assignments=Algo,Linear`
- Pagination: `page` (0), `size` (20 up to 100)
- Sort: `sort=field,asc|desc` (default `roll,asc`)

Example:
```
/api/employee?minScore=80&adDate=2024-05-10&courses=comp&assignments=algo&size=10
```

### 2) GET `/api/employee{id}`
Returns detailed student data including course, assignments, and the **last 3** performance records (by `adDate` desc).

## Notes on Schema Assumptions
The provided schema listed some ambiguous column names. To meet the endpoint requirements and follow conventions:
- Primary keys are numeric auto IDs except `student.roll`, retained as the student identifier (per your spec).
- `Assignment` relates to both `Course` and `Student` so we can filter students by assignment name(s).
- `Student_Project` is modeled as a join entity with an embedded id `(student, course, givenDate)` plus `tech`.
- `Performance` has its own `id` and references `Student`.

These choices keep relationships normalized and expressive while matching the functional needs.

## Quality & Conventions
- DTOs decouple API from entities.
- Service layer contains business logic.
- JPA Specifications power composable filtering.
- Validation on request params; global error handler.
- OpenAPI via springdoc for discoverability.
- H2 in-memory DB + sample data for quick testing.
- `open-in-view=false` and transactions: safe JPA usage.

## Next Steps (if needed)
- Add integration tests with Testcontainers (PostgreSQL/MySQL).
- Add caching if datasets are large.
- Add CI workflow.
