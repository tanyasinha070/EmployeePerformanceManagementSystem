
package com.example.epms.service;

import com.example.epms.domain.Project;
import com.example.epms.domain.Department;
import com.example.epms.domain.PerformanceReview;
import com.example.epms.domain.Employee;
import org.springframework.data.jpa.domain.Specification;

import jakarta.persistence.criteria.Join;
import java.time.LocalDate;
import java.util.List;

public class EmployeeSpecifications {

    public static Specification<Employee> hasPerformanceScoreOnDate(Integer minScore, LocalDate reviewDate) {
        if (minScore == null || reviewDate == null) return (root, q, cb) -> cb.conjunction();
        return (root, q, cb) -> {
            Join<Employee, PerformanceReview> perf = root.join("performanceReview");
            return cb.and(
                    cb.equal(perf.get("reviewDate"), reviewDate),
                    cb.greaterThanOrEqualTo(perf.get("score"), minScore)
            );
        };
    }

    public static Specification<Employee> departmentNameContainsAny(List<String> departmentParts) {
        if (departmentParts == null || departmentParts.isEmpty()) return (root, q, cb) -> cb.conjunction();
        return (root, q, cb) -> {
            Join<Employee, Department> c = root.join("department");
            return cb.or(departmentParts.stream()
                    .map(p -> cb.like(cb.lower(c.get("name")), "%" + p.toLowerCase() + "%"))
                    .toArray(jakarta.persistence.criteria.Predicate[]::new));
        };
    }

    public static Specification<Employee> projectNameContainsAny(List<String> projectParts) {
        if (projectParts == null || projectParts.isEmpty()) return (root, q, cb) -> cb.conjunction();
        return (root, q, cb) -> {
            Join<Employee, Project> a = root.join("project");
            return cb.or(projectParts.stream()
                    .map(p -> cb.like(cb.lower(a.get("name")), "%" + p.toLowerCase() + "%"))
                    .toArray(jakarta.persistence.criteria.Predicate[]::new));
        };
    }
}
