
package com.example.epms.api.dto;

import java.time.LocalDate;

public record PerformanceReviewDto(Long id, LocalDate reviewDate, Integer score, String reviewComments) {}
