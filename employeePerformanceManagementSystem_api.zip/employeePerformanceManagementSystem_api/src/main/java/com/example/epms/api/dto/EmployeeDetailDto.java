
package com.example.epms.api.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public record EmployeeDetailDto(
        Long id,
        String name,
        String email,
        LocalDate dateOfJoining,
        BigDecimal salary,
        DepartmentDto department,
        List<ProjectDto> project,
        List<PerformanceReviewDto> recentPerformances
) {}
