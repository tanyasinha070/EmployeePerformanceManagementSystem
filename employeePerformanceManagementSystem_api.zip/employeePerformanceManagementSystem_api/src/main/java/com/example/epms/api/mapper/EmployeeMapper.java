
package com.example.epms.api.mapper;

import com.example.epms.api.dto.*;
import com.example.epms.domain.*;

import java.util.List;

public class EmployeeMapper {
    public static EmployeeListItemDto toListItem(Employee s) {
        return new EmployeeListItemDto(s.getId(), s.getName(), s.getEmail(),
                s.getDepartment().getName(), s.getDateOfJoining(), s.getSalary());
    }

    public static DepartmentDto toDto(Department c) {
        return new DepartmentDto(c.getId(), c.getName(), c.getBudget());
    }

    public static ProjectDto toDto(Project a) {
        return new ProjectDto(a.getId(), a.getName(), a.getStartDate(), a.getEndDate(), a.getDepartment().getId());
    }

    public static PerformanceReviewDto toDto(PerformanceReview p) {
        return new PerformanceReviewDto(p.getId(), p.getReviewDate(), p.getScore(), p.getReviewComments());
    }

    public static EmployeeDetailDto toDetail(Employee s, List<Project> project, List<PerformanceReview> recents) {
        return new EmployeeDetailDto(
                s.getId(),
                s.getName(),
                s.getEmail(),
                s.getDateOfJoining(),
                s.getSalary(),
                toDto(s.getDepartment()),
                project.stream().map(EmployeeMapper::toDto).toList(),
                recents.stream().map(EmployeeMapper::toDto).toList()
        );
    }
}
