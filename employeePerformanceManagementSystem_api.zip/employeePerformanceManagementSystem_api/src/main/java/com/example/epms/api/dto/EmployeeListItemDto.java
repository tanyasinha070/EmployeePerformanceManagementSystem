
package com.example.epms.api.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public record EmployeeListItemDto(Long id, String name, String email, String departmentId, LocalDate dateOfJoining, BigDecimal salary) {}
