
package com.example.epms.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Table(name = "employee_project")
public class EmployeeProject {
    @EmbeddedId
    private EmployeeProject employee_id;

    private String role;
}
