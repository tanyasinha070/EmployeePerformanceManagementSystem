
package com.example.epms.api;

import com.example.epms.api.dto.EmployeeDetailDto;
import com.example.epms.api.dto.EmployeeListItemDto;
import com.example.epms.service.EmployeeService;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/employee")
@RequiredArgsConstructor
@Validated
public class EmployeeController {

    private final EmployeeService employeeService= new EmployeeService();

    // 1) List with filters
    @GetMapping
    public Page<EmployeeListItemDto> listStudents(
            @RequestParam(required = false) @Min(0) @Max(100) Integer minScore,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate reviewDate,
            @RequestParam(required = false, name = "department") String departmentContains,
            @RequestParam(required = false, name = "project") String projectContains,
            @RequestParam(defaultValue = "0") @Min(0) int page,
            @RequestParam(defaultValue = "20") @Min(1) @Max(100) int size,
            @RequestParam(defaultValue = "id,asc") String sort
    ) {
        String[] sortParts = sort.split(",");
        Sort s = Sort.by(sortParts.length > 1 && sortParts[1].equalsIgnoreCase("desc") ? Sort.Direction.DESC : Sort.Direction.ASC,
                sortParts[0]);
        Pageable pageable = PageRequest.of(page, size, s);
        return employeeService.searchEmployee(minScore, reviewDate, departmentContains, projectContains, pageable);
    }

    // 2) Detail with last 3 performances
    @GetMapping("/{id}")
    public ResponseEntity<EmployeeDetailDto> getDetail(@PathVariable Long roll) {
        return employeeService.getStudentDetail(roll)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
