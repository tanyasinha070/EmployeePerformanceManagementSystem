
package com.example.epms.api.dto;

import java.math.BigDecimal;

public record DepartmentDto(Long id, String name, BigDecimal budget) {}
