
package com.example.epms.service;

import com.example.epms.api.dto.EmployeeDetailDto;
import com.example.epms.api.dto.EmployeeListItemDto;
import com.example.epms.api.mapper.EmployeeMapper;
import com.example.epms.domain.Project;
import com.example.epms.domain.Employee;
import com.example.epms.domain.PerformanceReview;
import com.example.epms.repo.PerformanceReviewRepository;
import com.example.epms.repo.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service @RequiredArgsConstructor
@Transactional(readOnly = true)
public class EmployeeService {
    private final EmployeeRepository employeeRepository = null;
    private final PerformanceReviewRepository performanceReviewRepository = null;

    public Page<EmployeeListItemDto> searchEmployee(Integer minScore, LocalDate reviewDate, String department, String projectsContains, Pageable pageable) {
        List<String> departmentParts = splitCsv(department);
        List<String> projectParts = splitCsv(projectsContains);

        Specification<Employee> spec = Specification.where(EmployeeSpecifications.hasPerformanceScoreOnDate(minScore, reviewDate))
                .and(EmployeeSpecifications.departmentNameContainsAny(departmentParts))
                .and(EmployeeSpecifications.projectNameContainsAny(projectParts));

        return employeeRepository.findAll(spec, ((PageRequest) pageable).withSort(pageable.getSort()))
                .map(EmployeeMapper::toListItem);
    }

    public Optional<EmployeeDetailDto> getStudentDetail(Long roll) {
        return employeeRepository.findById(roll).map(s -> {
            // Load assignments lazily
            List<Project> project = s.getProject();
            List<PerformanceReview> recent = performanceReviewRepository.findByStudent_RollOrderByAdDateDesc(roll, PageRequest.of(0,3));
            return EmployeeMapper.toDetail(s, project, recent);
        });
    }

    private static List<String> splitCsv(String csv) {
        if (csv == null || csv.isBlank()) return List.of();
        return Arrays.stream(csv.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList();
    }
}
