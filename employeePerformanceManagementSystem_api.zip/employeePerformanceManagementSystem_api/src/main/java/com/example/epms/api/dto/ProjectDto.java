
package com.example.epms.api.dto;

import java.time.LocalDate;

public record ProjectDto(Long id, String name, LocalDate startDate, LocalDate endDate, Long departmentId) {}
