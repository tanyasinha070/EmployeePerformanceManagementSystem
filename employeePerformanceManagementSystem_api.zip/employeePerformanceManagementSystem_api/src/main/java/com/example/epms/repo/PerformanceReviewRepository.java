
package com.example.epms.repo;

import com.example.epms.domain.PerformanceReview;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PerformanceReviewRepository extends JpaRepository<PerformanceReview, Long> {
    List<PerformanceReview> findByStudent_RollOrderByAdDateDesc(Long roll, Pageable pageable);
}
