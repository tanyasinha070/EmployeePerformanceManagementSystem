
package com.example.epms.domain;

import jakarta.persistence.Embeddable;
import jakarta.persistence.ManyToOne;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

@Embeddable @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class EmployeeProjectId implements Serializable {
    @ManyToOne(optional = false)
    private Employee employee;

    @ManyToOne(optional = false)
    private Department department;

    private LocalDate assignedDate;

    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof EmployeeProjectId that)) return false;
        return Objects.equals(employee.getId(), that.employee.getId())
                && Objects.equals(department.getId(), that.department.getId())
                && Objects.equals(assignedDate, that.assignedDate);
    }
    @Override public int hashCode() {
        return Objects.hash(employee.getId(), department.getId(), assignedDate);
    }
}
