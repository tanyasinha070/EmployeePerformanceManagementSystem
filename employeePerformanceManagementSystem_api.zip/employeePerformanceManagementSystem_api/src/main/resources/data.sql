
INSERT INTO department(id, name, budget) VALUES (1,'Computer Science', 100000.00);
INSERT INTO department(id, name, budget) VALUES (2,'Electronics', 80000.00);
INSERT INTO department(id, name, budget) VALUES (3,'Mathematics', 50000.00);

INSERT INTO employee(id, name, email, department_id, date_of_joining, salary) VALUES (101,'Aarav','aarav@example.com',1,'2023-07-01',50000);
INSERT INTO employee(id, name, email, department_id, date_of_joining, salary, manager_id) VALUES (102,'Diya','diya@example.com',2,'2023-07-01',52000,101);
INSERT INTO employee(id, name, email, department_id, date_of_joining, salary) VALUES (103,'Kabir','kabir@example.com',1,'2024-01-10',48000);
INSERT INTO employee(id, name, email, department_id, date_of_joining, salary) VALUES (104,'Maya','maya@example.com',3,'2024-03-15',43000);

-- project (each tied to a department and a employee for filter semantics)
INSERT INTO project(id, name, start_date, end_date, department_id, department_id) VALUES (1,'Data Structures','2024-04-01','2024-04-15',1,101);
INSERT INTO project(id, name, start_date, end_date, department_id, department_id) VALUES (2,'Circuits Basics','2024-04-05','2024-04-20',2,102);
INSERT INTO project(id, name, start_date, end_date, department_id, department_id) VALUES (3,'Algorithms','2024-05-01','2024-05-20',1,103);
INSERT INTO project(id, name, start_date, end_date, department_id, department_id) VALUES (4,'Linear Algebra','2024-06-01','2024-06-30',3,104);
INSERT INTO project(id, name, start_date, end_date, department_id, department_id) VALUES (5,'Advanced Algorithms','2024-07-01','2024-07-31',1,101);

-- Performance samples
INSERT INTO performanceReview(id, employee_id, review_date, score, review_comments) VALUES (1,101,'2024-04-10',85,'Good');
INSERT INTO performanceReview(id, employee_id, review_date, score, review_comments) VALUES (2,101,'2024-05-10',90,'Great');
INSERT INTO performanceReview(id, employee_id, review_date, score, review_comments) VALUES (3,101,'2024-06-10',70,'Average');
INSERT INTO performanceReview(id, employee_id, review_date, score, review_comments) VALUES (4,102,'2024-04-10',88,'Nice');
INSERT INTO performanceReview(id, employee_id, review_date, score, review_comments) VALUES (5,103,'2024-05-10',92,'Excellent');
INSERT INTO performanceReview(id, employee_id, review_date, score, review_comments) VALUES (6,104,'2024-06-10',65,'Needs work');

-- Employee Projects (join entity)
INSERT INTO employee_projectt(employee_id, project_id, assigned_date, role) VALUES (101,1,'2024-07-20','Java');
INSERT INTO employee_project(employee_id, project_id, assigned_date, role) VALUES (101,1,'2024-08-01','Spring Boot');
INSERT INTO employee_project(employee_id, project_id, assigned_date, role) VALUES (102,2,'2024-07-25','Embedded C');
